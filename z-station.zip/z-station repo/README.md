# Integration HACS — Z-Station Bridge

![Home Assistant](https://img.shields.io/badge/Home%20Assistant-Custom%20Integration-blue)
![HACS](https://img.shields.io/badge/HACS-Custom-red)

The **Z-Station Bridge** is a Home Assistant custom integration used by the **Z-Station** mobile application.  
It exposes optimized and structured JSON REST endpoints for retrieving devices, refreshing states, controlling actuators, and reading zones.

---

Compatible with Home Assistant ≥ 2024.1  
Tested on : Core, OS, Container



## 🚀 REST Endpoints


### ✔ `/api/zstation/getdevices`
Returns all Home Assistant entities 
- sensors → sensor, binary_sensor  
- actuators → switch, light, fan, cover, climate, media_player, etc.

Each entity contains:
- Entity ID   
- attributes  
- zone  
- actionable values (brightness, temperature, cover position, etc.)

---

### ✔ `/api/zstation/refresh_devices`
Returns all Home Assistant entities 
- sensors → sensor, binary_sensor  
- actuators → switch, light, fan, cover, climate, media_player, etc.

Each entity contains:
- Entity ID   
- zone  
- value
- actionable values (brightness, temperature, cover position, etc.)

---

### ✔ `/api/zstation/execute_action`
Execute any Home Assistant action:

```json
POST /api/zstation/execute_action
{
  "entity_id": "light.salon",
  "zone": "Salon",
  "attributes": {
    "brightness": 180,
    "color_temp": 350
  },
  "state": "on"
}

```

---

### ✔ `/api/zstation/getzone`
Returns Home Assistant zones .

---

## 📁 Folder structure

```
zstation/
 ├── custom_components/
 │     └── zstation/
 │          ├── __init__.py
 │          ├── devices_api.py
 │          ├── refresh_devices_api.py
 │          ├── execute_action_api.py
 │          ├── zones_api.py
 │          ├── manifest.json
 │          ├── config_flow.py
 │          ├── const.py
 │          └── icon.png 
 ├── README.md
 ├── LICENSE
 ├── hacs.json
 └── zstation.zip (release asset)
```

---

## 🔧 Install via HACS (Custom Repository)

1. Open **HACS → Integrations**
2. Menu (⋮) → **Custom Repositories**
3. Add your GitHub repo:
   ```
   https://github.com/Z-Station-APP/Bridge-HA.git
   ```
4. Type: **Integration**
5. Install
6. Restart Home Assistant

---

## 🔧 Manual Installation

Extract this folder into:

```
/config/custom_components/zstation/
```

Restart Home Assistant.

---

## 📝 License

MIT License — see LICENSE file.
